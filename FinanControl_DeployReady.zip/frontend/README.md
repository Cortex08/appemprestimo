FinanControl Frontend - Netlify-ready
------------------------------------

1. Site files are in the `static/` folder. Drop the `frontend` folder into Netlify or connect a repo.
2. `netlify.toml` included; it proxies `/api/*` to the backend URL: https://financontrol-api.onrender.com
3. After deploy, configure the site domain and make sure the API URL (Render) is reachable.
